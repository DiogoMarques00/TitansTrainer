﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TitansTrainer
{
    class JogadorProfissional : Jogador
    {
        private int m_Moedas;

        public int Moedas
        {
            get
            {
                return m_Moedas;
            }
            set
            {
                int m_Moedas = value;
            }
        }

        public JogadorProfissional(string NickName, int CombatPower, int Moedas) : base(NickName, CombatPower)
        {
            m_Moedas = 10;
        }
    }

}
