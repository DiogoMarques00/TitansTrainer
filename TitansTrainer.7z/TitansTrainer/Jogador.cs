﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TitansTrainer
{
    public abstract class Jogador
    {
        private string m_ApostaAtual;
        private int m_CombatPower;
        private int m_GamePoints;
        private int m_Moedas;
        private string m_NickName;
        private Jogador[] m_ListaJogadores;
        private int m_NumeroCombatesRealizados;
        private string m_Powerups;
        private bool m_TemHabilidadeSecreta;
        private string m_TipoSubscricao;


        public string ApostaAtual
        {
            get
            {
                return m_ApostaAtual;
            }
            set
            {
                m_ApostaAtual = value;
            }
        }

        public int CombatPower
        {
            get
            {
                return m_CombatPower;
            }
            set
            {
                m_CombatPower = value;
            }
        }

        public int GamePoints
        {
            get
            {
                return m_GamePoints;
            }
            set
            {
                m_GamePoints = value;
            }
        }

      
        public string NickName
        {
            get
            {
                return m_NickName;
            }
            set
            {
                m_NickName = value;
            }
        }

        public Jogador[] ListaJogadores
        {
            get 
            {
                return m_ListaJogadores;
            }
            set
            {
                m_ListaJogadores = value;
            }
        }
        public int NumeroCombatesRealizados
        {
            get
            {
                return m_NumeroCombatesRealizados;
            }
            set
            {
                m_NumeroCombatesRealizados = value;
            }
        }

        public string PowerUps
        {
            get
            {
                return m_Powerups;
            }
            set
            {
                m_Powerups = value;
            }
        }

        public bool TemHabilidadeSecreta
        {
            get 
            {
                return m_TemHabilidadeSecreta;
            }
            set
            {
                m_TemHabilidadeSecreta = value;
            }
        }

        public string TipoSubscricao
        {
            get
            {
                return m_TipoSubscricao;
            }
            set
            {
                m_TipoSubscricao = value;
            }
        }
        public Jogador(string NickName, int CombatPower)
        {
            m_NickName = NickName;
            m_CombatPower = CombatPower;
            m_Powerups = "Vazio";
            m_GamePoints = 0;
            m_NumeroCombatesRealizados = 0;
        }

        public double TitanCP()
        {
            CombatPower
        }
        
    }
}
